import pymath as pm

 result = pm.add(5, 3)
 print(result)

 result = pm.divide(8 , 2)
 print(result)

 A = pm.Matrix(3,3,[1,2,3,4,5,6,7,8,9])
 B = pm.Matrix(3,1,[1,5,9])


 print(A.add(A))
 print()
 print(A.multiply(B))

X=[1,2,3,4,5]

print(pm.calculate_variance(X))

